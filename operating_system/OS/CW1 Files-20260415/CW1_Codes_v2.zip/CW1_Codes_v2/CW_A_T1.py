from data_T1 import _all_payLoads
import numpy as np
data_1, data_2, data_3, data_4, data_5 = _all_payLoads

#Write your code here and print the results
#T1.1

#T1.2

#T1.3
